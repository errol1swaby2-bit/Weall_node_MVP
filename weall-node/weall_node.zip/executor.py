# executor.py
import time
from collections import defaultdict
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from weall_runtime.ledger import _global_ledger as ledger  # Dynamic ledger singleton

# -----------------------------
# Encryption helpers
# -----------------------------
def generate_keypair():
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()
    return private_key, public_key

def encrypt_message(pub_key, message: str) -> bytes:
    return pub_key.encrypt(
        message.encode(),
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
    )

def decrypt_message(priv_key, ciphertext: bytes) -> str:
    return priv_key.decrypt(
        ciphertext,
        padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
    ).decode()

# -----------------------------
# WeAllExecutor
# -----------------------------
class WeAllExecutor:
    def __init__(self, poh_requirements=None):
        self.ledger = ledger
        self.current_epoch = 0
        self.poh_requirements = poh_requirements or {}
        self.state = {
            "users": {},      # user_id -> keys, PoH level, friends, groups
            "posts": {},      # post_id -> content
            "comments": {},   # comment_id -> content
            "disputes": {},   # dispute_id -> data
            "messages": defaultdict(list),
        }
        self.next_post_id = 1
        self.next_comment_id = 1
        self.next_dispute_id = 1

    # -----------------------------
    # User Management
    # -----------------------------
    def register_user(self, user_id, poh_level=1):
        if user_id in self.state["users"]:
            return {"ok": False, "error": "user_already_exists"}
        priv, pub = generate_keypair()
        self.state["users"][user_id] = {
            "poh_level": poh_level,
            "private_key": priv,
            "public_key": pub,
            "friends": [],
            "groups": []
        }
        # Register in ledger with tier = poh_level
        self.ledger.register_user(user_id, tier=poh_level)
        self.ledger.set_user_eligible(user_id, True)
        return {"ok": True}

    # -----------------------------
    # Posts
    # -----------------------------
    def create_post(self, user_id, content, tags=None, reward_amount=10, groups=None):
        if user_id not in self.state["users"]:
            return {"ok": False, "error": "user_not_registered"}
        post_id = self.next_post_id
        self.next_post_id += 1
        ipfs_hash = self.ledger.add_bytes(content.encode())
        self.state["posts"][post_id] = {
            "post_id": post_id,
            "user": user_id,
            "content_hash": ipfs_hash,
            "tags": tags or [],
            "groups": groups or [],
            "comments": [],
            "likes": 0,
            "timestamp": time.time()
        }
        # Reward user
        self.ledger.wecoin.deposit(user_id, reward_amount)
        self.ledger._update_pools_for_user(user_id)
        return {"ok": True, "post_id": post_id, "ipfs_hash": ipfs_hash}

    # -----------------------------
    # Comments
    # -----------------------------
    def create_comment(self, user_id, post_id, content, tags=None, reward_amount=5):
        if user_id not in self.state["users"]:
            return {"ok": False, "error": "user_not_registered"}
        if post_id not in self.state["posts"]:
            return {"ok": False, "error": "post_not_found"}
        cid = self.next_comment_id
        self.next_comment_id += 1
        ipfs_hash = self.ledger.add_bytes(content.encode())
        self.state["comments"][cid] = {
            "user": user_id,
            "post_id": post_id,
            "content_hash": ipfs_hash,
            "tags": tags or []
        }
        self.state["posts"][post_id]["comments"].append(cid)
        self.ledger.wecoin.deposit(user_id, reward_amount)
        self.ledger._update_pools_for_user(user_id)
        return {"ok": True, "comment_id": cid, "ipfs_hash": ipfs_hash}

    # -----------------------------
    # Disputes
    # -----------------------------
    def create_dispute(self, reporter_id, target_post_id, description, reward_amount=15):
        if reporter_id not in self.state["users"]:
            return {"ok": False, "error": "user_not_registered"}
        if target_post_id not in self.state["posts"]:
            return {"ok": False, "error": "post_not_found"}
        dispute_id = self.next_dispute_id
        self.next_dispute_id += 1
        ipfs_hash = self.ledger.add_bytes(description.encode())
        self.state["disputes"][dispute_id] = {
            "dispute_id": dispute_id,
            "reporter": reporter_id,
            "target_post": target_post_id,
            "description_hash": ipfs_hash,
            "status": "open",
            "jurors": [],
            "votes": {}
        }
        self.ledger.wecoin.deposit(reporter_id, reward_amount)
        self.ledger._update_pools_for_user(reporter_id)
        return {"ok": True, "dispute_id": dispute_id, "ipfs_hash": ipfs_hash}

    # -----------------------------
    # NFT Minting
    # -----------------------------
    def mint_nft(self, account, nft_id, metadata):
        if account not in self.state["users"]:
            return {"ok": False, "error": "user_not_registered"}
        ipfs_hash = self.ledger.add_bytes(metadata.encode())
        self.ledger.wecoin.deposit(account, 20)
        self.ledger._update_pools_for_user(account)
        return {"ok": True, "nft_id": nft_id, "ipfs_hash": ipfs_hash}

    # -----------------------------
    # Epoch / Rewards
    # -----------------------------
    def advance_epoch(self):
        winners = self.ledger.advance_epoch()
        self.current_epoch = self.ledger.current_epoch
        return winners

    # -----------------------------
    # Feed logic: tags -> engagement -> friends/groups
    # -----------------------------
    def get_feed(self, user_id, tags=None, max_posts=20):
        if user_id not in self.state["users"]:
            return []
        user = self.state["users"][user_id]
        eligible_posts = []

        for pid, post in self.state["posts"].items():
            author_tier = self.state["users"].get(post["user"], {}).get("poh_level", 0)
            if author_tier < 1:
                continue
            if tags and not any(tag in post.get("tags", []) for tag in tags):
                continue
            eligible_posts.append(post)

        def score(post):
            likes = post.get("likes", 0)
            comments = len(post.get("comments", []))
            base = likes + comments
            social_boost = 0
            if post["user"] in user.get("friends", []):
                social_boost += 2
            if any(g in user.get("groups", []) for g in post.get("groups", [])):
                social_boost += 1
            return base + social_boost

        sorted_posts = sorted(eligible_posts, key=score, reverse=True)
        return sorted_posts[:max_posts]

    # -----------------------------
    # Messaging
    # -----------------------------
    def send_message(self, from_user, to_user, message_text):
        if from_user not in self.state["users"] or to_user not in self.state["users"]:
            return {"ok": False, "error": "user_not_registered"}
        pub = self.state["users"][to_user]["public_key"]
        encrypted = encrypt_message(pub, message_text)
        self.state["messages"][to_user].append({
            "from": from_user,
            "encrypted": encrypted,
            "timestamp": time.time()
        })
        return {"ok": True}

    def read_messages(self, user_id):
        if user_id not in self.state["users"]:
            return {"ok": False, "error": "user_not_registered"}
        priv = self.state["users"][user_id]["private_key"]
        msgs = []
        for m in self.state["messages"][user_id]:
            try:
                text = decrypt_message(priv, m["encrypted"])
            except Exception:
                text = "[decryption_failed]"
            msgs.append({"from": m["from"], "text": text, "timestamp": m["timestamp"]})
        return msgs
