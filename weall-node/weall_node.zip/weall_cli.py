# weall_runtime.py
import time
from collections import defaultdict
from executor import WeAllExecutor

# Default required PoH levels per action
POH_REQUIREMENTS = {
    "propose": 3,
    "vote": 2,
    "post": 2,
    "comment": 2,
    "edit_post": 2,
    "delete_post": 2,
    "edit_comment": 2,
    "delete_comment": 2,
    "deposit": 2,
    "list_user_posts": 1,
    "list_tag_posts": 1,
    "report": 2,
    "dispute": 3,
    "juror": 3
}

def safe_int_input(prompt):
    try:
        return int(input(prompt))
    except ValueError:
        print("Invalid input, expected a number.")
        return None

def run_cli():
    executor = WeAllExecutor(poh_requirements=POH_REQUIREMENTS)
    print("WeAll CLI started. Type 'exit' to quit.")

    while True:
        cmd = input(
            "\nCommand (register/propose/vote/post/comment/show_post/show_posts/edit_post/delete_post/"
            "edit_comment/delete_comment/list_user_posts/list_tag_posts/report_post/report_comment/"
            "create_dispute/juror_vote/show_disputes/show_dispute/deposit/transfer/balance/"
            "send_message/read_messages/advance_epoch/mint_nft/show_pool/show_epoch_winners/"
            "feed/leaderboard/exit): "
        ).strip().lower()

        if cmd == "exit":
            break

        # ------------------------
        # User Management
        # ------------------------
        elif cmd == "register":
            user = input("User ID: ")
            poh = safe_int_input("PoH Level: ")
            result = executor.register_user(user, poh_level=poh)
            if result["ok"]:
                print(f"User '{user}' registered successfully.")
            else:
                print(result["error"])

        # ------------------------
        # Proposals / Governance
        # ------------------------
        elif cmd == "propose":
            user = input("User ID: ")
            title = input("Proposal title: ")
            desc = input("Proposal description: ")
            pallet = input("Pallet reference: ")
            print("[CLI] Proposal creation not implemented yet.")

        elif cmd == "vote":
            user = input("User ID: ")
            pid = safe_int_input("Proposal ID: ")
            option = input("Vote option: ")
            print("[CLI] Voting not implemented yet.")

        # ------------------------
        # Posts
        # ------------------------
        elif cmd == "post":
            user = input("User ID: ")
            content = input("Post content: ")
            tags = input("Tags (comma-separated, optional): ").split(",") if input("Add tags? (y/n): ").lower() == "y" else None
            res = executor.create_post(user, content, tags)
            print(res)

        elif cmd == "comment":
            user = input("User ID: ")
            pid = safe_int_input("Post ID: ")
            content = input("Comment content: ")
            tags = input("Tags (comma-separated, optional): ").split(",") if input("Add tags? (y/n): ").lower() == "y" else None
            res = executor.create_comment(user, pid, content, tags)
            print(res)

        # ------------------------
        # Disputes
        # ------------------------
        elif cmd == "create_dispute":
            reporter = input("Reporter User ID: ")
            target_pid = safe_int_input("Target Post ID: ")
            description = input("Dispute description: ")
            res = executor.create_dispute(reporter, target_pid, description)
            print(res)

        elif cmd == "show_disputes":
            for did, dispute in executor.state["disputes"].items():
                print(f"{did}: {dispute}")

        elif cmd == "show_dispute":
            did = safe_int_input("Dispute ID: ")
            dispute = executor.state["disputes"].get(did)
            print(dispute if dispute else f"Dispute {did} not found.")

        # ------------------------
        # Ledger / balances
        # ------------------------
        elif cmd == "deposit":
            user = input("User ID: ")
            amt = safe_int_input("Amount to deposit: ")
            executor.ledger.wecoin.deposit(user, amt)
            print(f"{amt} deposited to {user}'s account")

        elif cmd == "transfer":
            from_user = input("From user: ")
            to_user = input("To user: ")
            amt = safe_int_input("Amount to transfer: ")
            ok = executor.ledger.wecoin.transfer(from_user, to_user, amt)
            print("Transfer successful" if ok else "Transfer failed")

        elif cmd == "balance":
            user = input("User ID: ")
            bal = executor.ledger.wecoin.balance(user)
            print(f"{user} balance: {bal}")

        # ------------------------
        # Messaging
        # ------------------------
        elif cmd == "send_message":
            sender = input("From user: ")
            recipient = input("To user: ")
            msg = input("Message text: ")
            res = executor.send_message(sender, recipient, msg)
            print(res)

        elif cmd == "read_messages":
            user = input("User ID: ")
            msgs = executor.read_messages(user)
            for m in msgs:
                print(f"From {m['from']} | {m['timestamp']}: {m['text']}")

        # ------------------------
        # Epoch / rewards
        # ------------------------
        elif cmd == "advance_epoch":
            winners = executor.advance_epoch()
            print(f"Epoch advanced: {executor.current_epoch}")
            print(f"Winners this epoch: {winners}")

        # ------------------------
        # NFT minting
        # ------------------------
        elif cmd == "mint_nft":
            user = input("User ID: ")
            nft_id = input("NFT ID: ")
            metadata = input("NFT metadata/content: ")
            res = executor.mint_nft(user, nft_id, metadata)
            print(res)

        # ------------------------
        # Pool / participation
        # ------------------------
        elif cmd == "show_pool":
            pool_name = input("Pool name (creators/jurors/operators): ").strip()
            try:
                pool_members = executor.ledger.wecoin.inner.lock().unwrap().pool_members.get(pool_name, set())
                last_participation = executor.ledger.last_participation.get(pool_name, {})
                print(f"Members of pool '{pool_name}':")
                for member in pool_members:
                    epoch = last_participation.get(member, 'never')
                    print(f" - {member} | last participation epoch: {epoch}")
            except Exception as e:
                print(f"Error reading pool: {e}")

        elif cmd == "show_epoch_winners":
            try:
                print("Last participation by pool (epoch winners):")
                for pool, winners in executor.ledger.last_participation.items():
                    print(f"{pool}:")
                    for user, epoch in winners.items():
                        print(f" - {user} | last epoch won: {epoch}")
            except Exception as e:
                print(f"Error reading epoch winners: {e}")

        # ------------------------
        # Feed
        # ------------------------
        elif cmd == "feed":
            user = input("User ID: ")
            tags = input("Filter tags (comma-separated, optional): ").split(",") if input("Filter by tags? (y/n): ").lower() == "y" else None
            feed_posts = executor.get_feed(user, tags=tags)
            print(f"Feed for {user}:")
            for post in feed_posts:
                print(f"- Post {post.get('post_id','N/A')} by {post['user']}: {post['content_hash']} | Likes: {post.get('likes',0)} | Comments: {len(post['comments'])}")

        # ------------------------
        # Leaderboard
        # ------------------------
        elif cmd == "leaderboard":
            try:
                stats = {}
                for user_id in executor.state["users"]:
                    balance = executor.ledger.wecoin.balance(user_id)
                    posts = sum(1 for p in executor.state["posts"].values() if p["user"] == user_id)
                    comments = sum(1 for c in executor.state["comments"].values() if c["user"] == user_id)
                    disputes = sum(1 for d in executor.state["disputes"].values() if d["reporter"] == user_id)
                    stats[user_id] = {"balance": balance, "posts": posts, "comments": comments, "disputes": disputes}

                sorted_stats = sorted(stats.items(), key=lambda x: (x[1]["balance"], x[1]["posts"], x[1]["comments"]), reverse=True)
                print("Leaderboard:")
                for user_id, s in sorted_stats:
                    print(f"{user_id}: Balance={s['balance']}, Posts={s['posts']}, Comments={s['comments']}, Disputes={s['disputes']}")
            except Exception as e:
                print(f"Error generating leaderboard: {e}")

        # ------------------------
        # Posts / tags
        # ------------------------
        elif cmd == "list_user_posts":
            user = input("User ID: ")
            posts = [pid for pid, p in executor.state["posts"].items() if p["user"] == user]
            print(f"Posts by {user}: {posts}")

        elif cmd == "list_tag_posts":
            tag = input("Tag to search: ")
            posts = [pid for pid, p in executor.state["posts"].items() if tag in p["tags"]]
            print(f"Posts with tag '{tag}': {posts}")

        elif cmd == "show_post":
            pid = safe_int_input("Post ID: ")
            post = executor.state["posts"].get(pid)
            print(post if post else f"Post {pid} not found.")

        elif cmd == "show_posts":
            for pid, post in executor.state["posts"].items():
                print(f"{pid}: {post}")

        else:
            print("Unknown command.")

if __name__ == "__main__":
    run_cli()
